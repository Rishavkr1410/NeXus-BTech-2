import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { GraduationCap, Briefcase, BookOpen, Trophy, Code, Menu, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import Jobs from './pages/Jobs';
import Internships from './pages/Internships';
import StudyMaterials from './pages/StudyMaterials';
import TechFests from './pages/TechFests';
import Home from './pages/Home';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <nav className={`fixed w-full z-50 transition-all duration-300 ${
          isScrolled ? 'bg-slate-900/95 backdrop-blur-lg shadow-lg' : 'bg-transparent'
        }`}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center">
                <Link to="/" className="flex items-center space-x-2 group">
                  <GraduationCap className="h-8 w-8 text-blue-500 group-hover:text-blue-400 transition-colors duration-300" />
                  <span className="text-2xl font-bold text-gradient">NeXus BTech</span>
                </Link>
              </div>

              <div className="hidden md:block">
                <div className="flex items-center space-x-4">
                  <NavLink to="/jobs">
                    <Briefcase className="h-4 w-4" />
                    Jobs
                  </NavLink>
                  <NavLink to="/internships">
                    <Code className="h-4 w-4" />
                    Internships
                  </NavLink>
                  <NavLink to="/study-materials">
                    <BookOpen className="h-4 w-4" />
                    Study Materials
                  </NavLink>
                  <NavLink to="/techfests">
                    <Trophy className="h-4 w-4" />
                    TechFests
                  </NavLink>
                </div>
              </div>

              <div className="md:hidden">
                <button
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="text-gray-300 hover:text-white p-2 transition-colors duration-200"
                >
                  {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
                </button>
              </div>
            </div>
          </div>

          {isMenuOpen && (
            <div className="md:hidden absolute w-full bg-slate-800/95 backdrop-blur-lg">
              <div className="px-2 pt-2 pb-3 space-y-1">
                <MobileNavLink to="/jobs" onClick={() => setIsMenuOpen(false)}>
                  <Briefcase className="h-4 w-4" />
                  Jobs
                </MobileNavLink>
                <MobileNavLink to="/internships" onClick={() => setIsMenuOpen(false)}>
                  <Code className="h-4 w-4" />
                  Internships
                </MobileNavLink>
                <MobileNavLink to="/study-materials" onClick={() => setIsMenuOpen(false)}>
                  <BookOpen className="h-4 w-4" />
                  Study Materials
                </MobileNavLink>
                <MobileNavLink to="/techfests" onClick={() => setIsMenuOpen(false)}>
                  <Trophy className="h-4 w-4" />
                  TechFests
                </MobileNavLink>
              </div>
            </div>
          )}
        </nav>

        <main className="pt-16">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/jobs" element={<Jobs />} />
            <Route path="/internships" element={<Internships />} />
            <Route path="/study-materials" element={<StudyMaterials />} />
            <Route path="/techfests" element={<TechFests />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

function NavLink({ to, children }: { to: string; children: React.ReactNode }) {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link
      to={to}
      className={`group flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-all duration-300 ${
        isActive 
          ? 'bg-blue-600 text-white' 
          : 'text-gray-300 hover:text-white hover:bg-blue-600/20'
      }`}
    >
      {children}
    </Link>
  );
}

function MobileNavLink({ to, children, onClick }: { to: string; children: React.ReactNode; onClick: () => void }) {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link
      to={to}
      onClick={onClick}
      className={`flex items-center space-x-2 px-3 py-2 rounded-md text-base font-medium transition-all duration-300 ${
        isActive 
          ? 'bg-blue-600 text-white' 
          : 'text-gray-300 hover:text-white hover:bg-blue-600/20'
      }`}
    >
      {children}
    </Link>
  );
}

export default App;