import React, { useState } from 'react';
import { Building2, MapPin, DollarSign, Search, Filter, Briefcase, Clock, Users } from 'lucide-react';

function Jobs() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');

  const jobs = [
    {
      company: "TechCorp Solutions",
      position: "Software Engineer",
      location: "Bangalore, India",
      salary: "₹8-12 LPA",
      experience: "0-2 years",
      type: "Full-time",
      requirements: ["B.Tech in CS/IT", "Strong in DSA", "React/Node.js"],
      responsibilities: [
        "Develop and maintain web applications",
        "Collaborate with cross-functional teams",
        "Write clean, maintainable code"
      ],
      postedDate: "2 days ago",
      applicants: "45",
      logo: "https://images.unsplash.com/photo-1549924231-f129b911e442?auto=format&fit=crop&q=80&w=100&h=100"
    },
    {
      company: "InnovateX",
      position: "Full Stack Developer",
      location: "Hyderabad, India",
      salary: "₹10-15 LPA",
      experience: "3+ years",
      type: "Remote",
      requirements: ["B.Tech", "3+ years exp", "MERN Stack"],
      responsibilities: [
        "Lead development of new features",
        "Mentor junior developers",
        "Optimize application performance"
      ],
      postedDate: "1 week ago",
      applicants: "78",
      logo: "https://images.unsplash.com/photo-1560179707-f14e90ef3623?auto=format&fit=crop&q=80&w=100&h=100"
    },
    {
      company: "DataTech Systems",
      position: "Machine Learning Engineer",
      location: "Pune, India",
      salary: "₹12-18 LPA",
      experience: "2-4 years",
      type: "Hybrid",
      requirements: ["M.Tech/B.Tech", "Python", "ML/AI", "TensorFlow"],
      responsibilities: [
        "Develop ML models",
        "Data analysis and preprocessing",
        "Model deployment and monitoring"
      ],
      postedDate: "3 days ago",
      applicants: "32",
      logo: "https://images.unsplash.com/photo-1568952433726-3896e3881c65?auto=format&fit=crop&q=80&w=100&h=100"
    }
  ];

  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = selectedFilter === 'all' || job.type.toLowerCase() === selectedFilter;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="animate-fade-in">
        <h1 className="text-4xl font-bold text-gradient mb-2">Latest Job Openings</h1>
        <p className="text-gray-400 mb-8">Find your dream job in top tech companies</p>

        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search jobs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-800/50 rounded-lg border border-slate-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all duration-300"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedFilter('all')}
              className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                selectedFilter === 'all' ? 'bg-blue-600 text-white' : 'bg-slate-800/50 text-gray-300 hover:bg-slate-700'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setSelectedFilter('remote')}
              className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                selectedFilter === 'remote' ? 'bg-blue-600 text-white' : 'bg-slate-800/50 text-gray-300 hover:bg-slate-700'
              }`}
            >
              Remote
            </button>
            <button
              onClick={() => setSelectedFilter('full-time')}
              className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                selectedFilter === 'full-time' ? 'bg-blue-600 text-white' : 'bg-slate-800/50 text-gray-300 hover:bg-slate-700'
              }`}
            >
              Full-time
            </button>
          </div>
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredJobs.map((job, index) => (
          <div
            key={index}
            className="group bg-slate-800/50 backdrop-blur-sm rounded-lg p-6 border border-slate-700 hover:border-blue-500 transition-all duration-300 card-shine animate-fade-in"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="flex items-center mb-4">
              <img
                src={job.logo}
                alt={job.company}
                className="w-12 h-12 rounded-full mr-4 object-cover"
              />
              <div>
                <h3 className="text-xl font-semibold text-white group-hover:text-blue-400 transition-colors duration-300">
                  {job.position}
                </h3>
                <div className="flex items-center text-gray-400">
                  <Building2 className="h-4 w-4 mr-1" />
                  {job.company}
                </div>
              </div>
            </div>
            
            <div className="space-y-3 mb-4">
              <div className="flex items-center text-gray-300">
                <MapPin className="h-4 w-4 mr-2" />
                {job.location}
              </div>
              <div className="flex items-center text-gray-300">
                <DollarSign className="h-4 w-4 mr-2" />
                {job.salary}
              </div>
              <div className="flex items-center text-gray-300">
                <Briefcase className="h-4 w-4 mr-2" />
                {job.type}
              </div>
              <div className="flex items-center text-gray-300">
                <Clock className="h-4 w-4 mr-2" />
                {job.experience}
              </div>
            </div>

            <div className="border-t border-slate-700 pt-4 mb-4">
              <h4 className="text-sm font-semibold text-gray-300 mb-2">Requirements:</h4>
              <ul className="list-disc list-inside text-gray-400 space-y-1">
                {job.requirements.map((req, i) => (
                  <li key={i}>{req}</li>
                ))}
              </ul>
            </div>

            <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
              <span className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                {job.postedDate}
              </span>
              <span className="flex items-center">
                <Users className="h-4 w-4 mr-1" />
                {job.applicants} applicants
              </span>
            </div>

            <button className="w-full btn-primary">
              Apply Now
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Jobs;