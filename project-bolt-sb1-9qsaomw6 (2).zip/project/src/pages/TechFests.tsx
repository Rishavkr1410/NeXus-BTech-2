import React from 'react';
import { Calendar, MapPin, Users, Trophy } from 'lucide-react';

function TechFests() {
  const events = [
    {
      title: "TechnoVision 2025",
      organizer: "IIT Bombay",
      date: "March 15-17, 2025",
      location: "Mumbai, India",
      participants: "5000+",
      prize: "₹10,00,000",
      image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80&w=400&h=250"
    },
    {
      title: "HackX 2025",
      organizer: "NIT Warangal",
      date: "April 5-6, 2025",
      location: "Warangal, India",
      participants: "2000+",
      prize: "₹5,00,000",
      image: "https://images.unsplash.com/photo-1504384764586-bb4cdc1707b0?auto=format&fit=crop&q=80&w=400&h=250"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-white mb-8">TechFests & Hackathons</h1>
      
      <div className="grid gap-8 md:grid-cols-2">
        {events.map((event, index) => (
          <div
            key={index}
            className="bg-slate-800/50 backdrop-blur-sm rounded-lg overflow-hidden border border-slate-700 hover:border-blue-500 transition-all duration-300"
          >
            <img
              src={event.image}
              alt={event.title}
              className="w-full h-64 object-cover"
            />
            
            <div className="p-6">
              <h3 className="text-2xl font-semibold text-white mb-2">{event.title}</h3>
              <p className="text-gray-400 mb-4">{event.organizer}</p>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="flex items-center text-gray-300">
                  <Calendar className="h-4 w-4 mr-2" />
                  {event.date}
                </div>
                <div className="flex items-center text-gray-300">
                  <MapPin className="h-4 w-4 mr-2" />
                  {event.location}
                </div>
                <div className="flex items-center text-gray-300">
                  <Users className="h-4 w-4 mr-2" />
                  {event.participants} participants
                </div>
                <div className="flex items-center text-gray-300">
                  <Trophy className="h-4 w-4 mr-2" />
                  Prize pool: {event.prize}
                </div>
              </div>

              <div className="flex space-x-4">
                <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded transition-colors duration-300">
                  Register Now
                </button>
                <button className="flex-1 border border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white font-semibold py-2 px-4 rounded transition-all duration-300">
                  Learn More
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default TechFests;