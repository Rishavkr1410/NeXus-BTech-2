import React from 'react';
import { ArrowRight, Briefcase, BookOpen, Trophy, Code } from 'lucide-react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div className="min-h-screen">
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80"
            alt="Campus"
            className="w-full h-full object-cover opacity-10"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-900/50 to-slate-900"></div>
        </div>
        
        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <h1 className="text-5xl sm:text-7xl font-bold mb-6 animate-fade-in text-gradient">
            Welcome to NeXus BTech
          </h1>
          <p className="text-xl sm:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto animate-fade-in" style={{ animationDelay: '0.2s' }}>
            Your gateway to opportunities, knowledge, and innovation in engineering
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-fade-in" style={{ animationDelay: '0.4s' }}>
            <FeaturedCard
              to="/jobs"
              icon={<Briefcase className="h-6 w-6" />}
              title="Jobs"
              description="Explore career opportunities"
              delay={0}
            />
            <FeaturedCard
              to="/internships"
              icon={<Code className="h-6 w-6" />}
              title="Internships"
              description="Gain practical experience"
              delay={0.1}
            />
            <FeaturedCard
              to="/study-materials"
              icon={<BookOpen className="h-6 w-6" />}
              title="Study Materials"
              description="Access learning resources"
              delay={0.2}
            />
            <FeaturedCard
              to="/techfests"
              icon={<Trophy className="h-6 w-6" />}
              title="TechFests"
              description="Participate in events"
              delay={0.3}
            />
          </div>
        </div>
      </section>

      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-bold mb-12 text-center text-gradient">
          Why Choose NeXus BTech?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <FeatureCard
            title="Career Growth"
            description="Connect with top companies and find your dream job through our extensive network."
            icon="🚀"
          />
          <FeatureCard
            title="Quality Resources"
            description="Access curated study materials and resources to excel in your academic journey."
            icon="📚"
          />
          <FeatureCard
            title="Tech Events"
            description="Stay updated with the latest hackathons and tech festivals to showcase your skills."
            icon="🏆"
          />
        </div>
      </section>
    </div>
  );
}

function FeaturedCard({ to, icon, title, description, delay }: {
  to: string;
  icon: React.ReactNode;
  title: string;
  description: string;
  delay: number;
}) {
  return (
    <Link
      to={to}
      className="group glass-effect p-6 rounded-xl card-hover animate-float"
      style={{ animationDelay: `${delay}s` }}
    >
      <div className="flex flex-col items-center text-center">
        <div className="text-blue-500 mb-4 group-hover:text-blue-400 transition-colors duration-300">
          {icon}
        </div>
        <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-blue-400 transition-colors duration-300">
          {title}
        </h3>
        <p className="text-gray-400 mb-4">{description}</p>
        <ArrowRight className="h-5 w-5 text-blue-500 transform group-hover:translate-x-2 transition-transform duration-300" />
      </div>
    </Link>
  );
}

function FeatureCard({ title, description, icon }: {
  title: string;
  description: string;
  icon: string;
}) {
  return (
    <div className="glass-effect p-8 rounded-xl card-hover">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-xl font-semibold text-white mb-3">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  );
}

export default Home;