import React from 'react';
import { Book, Download, Star } from 'lucide-react';

function StudyMaterials() {
  const materials = [
    {
      title: "Data Structures and Algorithms",
      subject: "Computer Science",
      type: "Course Notes",
      rating: 4.8,
      downloads: 1200,
      thumbnail: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&q=80&w=200&h=150"
    },
    {
      title: "Machine Learning Fundamentals",
      subject: "Artificial Intelligence",
      type: "Video Lectures",
      rating: 4.9,
      downloads: 980,
      thumbnail: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&q=80&w=200&h=150"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-white mb-8">Study Materials</h1>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {materials.map((material, index) => (
          <div
            key={index}
            className="bg-slate-800/50 backdrop-blur-sm rounded-lg overflow-hidden border border-slate-700 hover:border-blue-500 transition-all duration-300"
          >
            <img
              src={material.thumbnail}
              alt={material.title}
              className="w-full h-48 object-cover"
            />
            
            <div className="p-6">
              <h3 className="text-xl font-semibold text-white mb-2">{material.title}</h3>
              <div className="flex items-center text-gray-400 mb-4">
                <Book className="h-4 w-4 mr-2" />
                {material.subject}
              </div>
              
              <div className="flex justify-between items-center text-gray-300 mb-4">
                <div className="flex items-center">
                  <Star className="h-4 w-4 text-yellow-500 mr-1" />
                  {material.rating}
                </div>
                <div className="flex items-center">
                  <Download className="h-4 w-4 mr-1" />
                  {material.downloads}
                </div>
              </div>

              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded transition-colors duration-300">
                Download
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default StudyMaterials;