import React, { useState } from 'react';
import { Building2, Calendar, MapPin, Search, DollarSign, Briefcase, Users, GraduationCap } from 'lucide-react';

function Internships() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDuration, setSelectedDuration] = useState('all');

  const internships = [
    {
      company: "Google",
      position: "Software Engineering Intern",
      duration: "3 months",
      location: "Bangalore, India",
      stipend: "₹1,00,000/month",
      domain: "Software Development",
      requirements: [
        "B.Tech 3rd/4th year",
        "Strong coding skills",
        "DSA",
        "Good problem-solving skills"
      ],
      responsibilities: [
        "Work on real-world projects",
        "Collaborate with Google engineers",
        "Learn and implement best practices"
      ],
      perks: [
        "Certificate",
        "Performance bonus",
        "Return offer possibility"
      ],
      deadline: "March 30, 2025",
      positions: "15",
      logo: "https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?auto=format&fit=crop&q=80&w=100&h=100"
    },
    {
      company: "Microsoft",
      position: "Research Intern",
      duration: "6 months",
      location: "Hyderabad, India",
      stipend: "₹80,000/month",
      domain: "Machine Learning",
      requirements: [
        "B.Tech/M.Tech",
        "ML/AI knowledge",
        "Python",
        "Research aptitude"
      ],
      responsibilities: [
        "Conduct research in ML",
        "Publish technical papers",
        "Develop prototypes"
      ],
      perks: [
        "Research exposure",
        "Publication opportunity",
        "Mentorship"
      ],
      deadline: "April 15, 2025",
      positions: "8",
      logo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=100&h=100"
    },
    {
      company: "Amazon",
      position: "Data Science Intern",
      duration: "4 months",
      location: "Remote",
      stipend: "₹90,000/month",
      domain: "Data Science",
      requirements: [
        "B.Tech/M.Tech",
        "Statistics",
        "Python/R",
        "ML basics"
      ],
      responsibilities: [
        "Data analysis",
        "Model development",
        "Business insights"
      ],
      perks: [
        "Remote work",
        "Learning allowance",
        "Project ownership"
      ],
      deadline: "March 25, 2025",
      positions: "12",
      logo: "https://images.unsplash.com/photo-1620288627223-53302f4e8c74?auto=format&fit=crop&q=80&w=100&h=100"
    }
  ];

  const filteredInternships = internships.filter(internship => {
    const matchesSearch = internship.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         internship.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDuration = selectedDuration === 'all' || internship.duration.includes(selectedDuration);
    return matchesSearch && matchesDuration;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="animate-fade-in">
        <h1 className="text-4xl font-bold text-gradient mb-2">Internship Opportunities</h1>
        <p className="text-gray-400 mb-8">Kickstart your career with leading tech companies</p>

        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search internships..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-800/50 rounded-lg border border-slate-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all duration-300"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedDuration('all')}
              className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                selectedDuration === 'all' ? 'bg-blue-600 text-white' : 'bg-slate-800/50 text-gray-300 hover:bg-slate-700'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setSelectedDuration('3')}
              className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                selectedDuration === '3' ? 'bg-blue-600 text-white' : 'bg-slate-800/50 text-gray-300 hover:bg-slate-700'
              }`}
            >
              3 Months
            </button>
            <button
              onClick={() => setSelectedDuration('6')}
              className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                selectedDuration === '6' ? 'bg-blue-600 text-white' : 'bg-slate-800/50 text-gray-300 hover:bg-slate-700'
              }`}
            >
              6 Months
            </button>
          </div>
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredInternships.map((internship, index) => (
          <div
            key={index}
            className="group bg-slate-800/50 backdrop-blur-sm rounded-lg p-6 border border-slate-700 hover:border-blue-500 transition-all duration-300 card-shine animate-fade-in"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="flex items-center mb-4">
              <img
                src={internship.logo}
                alt={internship.company}
                className="w-12 h-12 rounded-full mr-4 object-cover"
              />
              <div>
                <h3 className="text-xl font-semibold text-white group-hover:text-blue-400 transition-colors duration-300">
                  {internship.position}
                </h3>
                <div className="flex items-center text-gray-400">
                  <Building2 className="h-4 w-4 mr-1" />
                  {internship.company}
                </div>
              </div>
            </div>
            
            <div className="space-y-3 mb-4">
              <div className="flex items-center text-gray-300">
                <Calendar className="h-4 w-4 mr-2" />
                Duration: {internship.duration}
              </div>
              <div className="flex items-center text-gray-300">
                <MapPin className="h-4 w-4 mr-2" />
                {internship.location}
              </div>
              <div className="flex items-center text-gray-300">
                <DollarSign className="h-4 w-4 mr-2" />
                Stipend: {internship.stipend}
              </div>
              <div className="flex items-center text-gray-300">
                <Briefcase className="h-4 w-4 mr-2" />
                Domain: {internship.domain}
              </div>
            </div>

            <div className="border-t border-slate-700 pt-4 mb-4">
              <h4 className="text-sm font-semibold text-gray-300 mb-2">Requirements:</h4>
              <ul className="list-disc list-inside text-gray-400 space-y-1">
                {internship.requirements.map((req, i) => (
                  <li key={i}>{req}</li>
                ))}
              </ul>
            </div>

            <div className="border-t border-slate-700 pt-4 mb-4">
              <h4 className="text-sm font-semibold text-gray-300 mb-2">Perks:</h4>
              <div className="flex flex-wrap gap-2">
                {internship.perks.map((perk, i) => (
                  <span key={i} className="px-2 py-1 bg-blue-600/20 text-blue-400 rounded-full text-sm">
                    {perk}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
              <span className="flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                Deadline: {internship.deadline}
              </span>
              <span className="flex items-center">
                <Users className="h-4 w-4 mr-1" />
                {internship.positions} positions
              </span>
            </div>

            <button className="w-full btn-primary">
              Apply Now
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Internships;